package com.mini.chest;

public class ClickType {
    public static int LEFT_CLICK = 0;
    public static int RIGHT_CLICK = 1;
}
